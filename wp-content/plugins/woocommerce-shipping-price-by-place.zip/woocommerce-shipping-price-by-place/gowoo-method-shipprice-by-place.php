<?php
class WC_Shipping_Price_by_Place extends WC_Shipping_Method {

	protected $shipdata;

	function __construct( $instance_id = 0 ) {
		$this->id 					= 'gowoo_shiplace';
		$this->enabled 				= 'yes';
		$this->instance_id 			= absint( $instance_id );
		$this->method_title 		= __('Shipping Price by Place','gowoo');
		$this->method_description	= __('It is a shipping method for Woocommerce where you can put a price on each local place of your region','gowoo');
		
		$this->init_form_fields();
		$this->init_settings();
		//$this->display_errors();

		$this->title 		  		= $this->get_option( 'title', __('Shipping Price by Place','gowoo') );
		$this->label_first 		  	= $this->get_option( 'label_first', __( 'Province', 'gowoo' ) );
		$this->label_second 		= $this->get_option( 'label_second', __( 'District', 'gowoo' ) );
		$this->availability 		= $this->get_option( 'availability' );
		$this->requifield 			= $this->get_option( 'requifield' );

		$this->supports 			= array(
											'shipping-zones',
											'instance-settings',
											'instance-settings-modal'
										);

		$this->shipdata['found'] = 0;

		//delete_transient( 'shipping-transient-version' );
		//$transient_value = WC_Cache_Helper::get_transient_version( 'shipping', true );
		//WC_Cache_Helper::delete_version_transients($transient_value);

		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
		//add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'save_place_details' ) );

		add_filter('woocommerce_cart_shipping_method_full_label', array($this,'label_when_zero'),10,2);
	}


	function init_form_fields() {

		$base_country = WC()->countries->get_base_country();
		$base_state = WC()->countries->get_base_state();

		$list_countries = WC()->countries->get_countries();
		$label_country = $list_countries[$base_country];

		$list_state = WC()->countries->get_states($base_country);
		$label_state = $list_state[$base_state];

		$this->instance_form_fields = array(
			'title' => array(
							'title' 		=> __( 'Method Title', 'woocommerce' ),
							'type' 			=> 'text',
							'description' 	=> __( 'This controls the title which the user sees during shipping.', 'gowoo' ),
							'default'		=> '',
							'desc_tip'		=> true
						),
			'select2_lib' => array(
							'title'			=> __('Select2() JQuery library','gowoo'),
							'type'			=> 'checkbox',
							'label' 		=> sprintf(__('Use <a href="%s" target="_blank">Select2()</a> for the select tag','gowoo'),'https://select2.github.io/'),
							'default' 		=> 'yes'
						),
			'requifield' => array(
							'title'			=> __('Required Field','gowoo'),
							'type'			=> 'checkbox',
							'label'			=> __('The field will be required','gowoo'),
							'default'		=> 'yes'
						),
			'label_first' => array(
							'title' 		=> __( 'Label First Level', 'gowoo' ),
							'type' 			=> 'text',
							'description' 	=> __( 'It is the name of first level. Example: Province', 'gowoo' ),
							'default'		=> __( 'Province', 'gowoo' ),
							'desc_tip'		=> false
						),
			'label_second' => array(
							'title' 		=> __( 'Label Second Level', 'gowoo' ),
							'type' 			=> 'text',
							'description' 	=> __( 'It is the name of second level. Example: District', 'gowoo' ),
							'default'		=> __( 'District', 'gowoo' ),
							'desc_tip'		=> false
						),
			'instance_id' => array(
							'type' => 'instance_id'
						),
			'hidden_view' => array(
							'type' => 'hidden_view'
						),
			'place_details' => array(
							'type'	=>	'place_details'
						)
		);
	}


	function generate_instance_id_html($key,$value) {
		ob_start();
		?>
		<input type="hidden" name="<?php echo $this->get_field_key($key); ?>" value="<?php echo $this->instance_id; ?>" />
		<?php
		return ob_get_clean();
	}

	function generate_hidden_view_html($key,$value) {
		ob_start();
		?>
		<input type="hidden" name="<?php echo $this->get_field_key($key); ?>" value="1" id="gowoo_hidden_view" />
		<?php
		return ob_get_clean();
	}

	function generate_place_details_html($key, $v) {
		ob_start();

		$this->label_first 	= $this->get_option( 'label_first', __( 'Province', 'gowoo' ) );
		$this->label_second = $this->get_option( 'label_second', __( 'District', 'gowoo' ) );
		$this->place_details = $this->get_option( 'place_details', array('select_places' => 'form_manual'));
		$key_input = $this->get_field_key( $key );
		$base_country = WC()->countries->get_base_country();
		$base_state = WC()->countries->get_base_state();

		$checked_place_manual = $checked_place_import = $display_manual = $display_import = '';

		if(isset($this->place_details['select_places'])) {
			switch($this->place_details['select_places']) {
				case 'form_manual' : 
							$checked_place_manual = 'CHECKED';
							$display_import = 'display:none;';
							break;
				case 'form_import' : 
							$checked_place_import = 'CHECKED';
							$display_manual = 'display:none;';
							break;
			}
		} else {
			$this->place_details['select_places'] = 'form_manual';
			$checked_place_manual = 'CHECKED';
			$display_import = 'display:none;';
		}
		?>

		<tr valign="top" class="gowoo_setting_places">
			<th scope="row" class="titledesc"><?php _e( 'Place Details', 'gowoo' ); ?>:</th>
			<td class="forminp" id="gowoo_places">
				<fieldset>
					<label for="select_places_manual"><input type="radio" class="select_places" name="<?php echo $key_input; ?>[select_places]" id="select_places_manual" value="form_manual" style="min-width: 16px; width: 20%;" <?php echo $checked_place_manual; ?> /> <?php _e('Manual','gowoo'); ?></label>
					<label for="select_places_import"><input type="radio" class="select_places" name="<?php echo $key_input; ?>[select_places]" id="select_places_import" value="form_import" style="min-width: 16px; width: 11%;" <?php echo $checked_place_import; ?> /> <?php _e('Import File','gowoo'); ?></label>
				</fieldset>

				<div id="form_manual" style="<?php echo $display_manual; ?>">

					<p><?php _e('If you want to load more than 20 rows, I recommend using the import mode','gowoo'); ?></p><br />

					<table class="widefat wc_input_table sortable" cellspacing="0">
						<thead>
							<tr>
								<th class="sort">&nbsp;</th>
								<th><?php _e( 'Country/State', 'gowoo' ); ?></th>
								<th><?php echo $this->label_first; ?></th>
								<th><?php echo $this->label_second; ?></th>
								<th><?php _e( 'Price', 'gowoo' ); ?></th>
							</tr>
						</thead>
						<tbody class="places">
						<?php
							$i = -1;
							if ( $this->place_details['select_places'] == 'form_manual' && isset($this->place_details['array_places']) ) {
								foreach ( $this->place_details['array_places'] as $place ) {

									$i++;
									$array_cod_country_state = explode(':',$place['cod_country']);
									$array_cod_country_state[1] = isset($array_cod_country_state[1])?$array_cod_country_state[1]:'*';

									echo '<tr class="place">
										<td class="sort"></td>
										<td>
											<select name="'.$key_input.'[array_places][' . $i . '][cod_country]">';
												WC()->countries->country_dropdown_options($array_cod_country_state[0],$array_cod_country_state[1],false);
										echo '</select>
										</td>
										<td><input type="text" value="' . esc_attr( wp_unslash( $place['first_level'] ) ) . '" name="'.$key_input.'[array_places][' . $i . '][first_level]" /></td>
										<td><input type="text" value="' . esc_attr( wp_unslash( $place['second_level'] ) ) . '" name="'.$key_input.'[array_places][' . $i . '][second_level]" /></td>
										<td><input type="text" value="' . esc_attr( wp_unslash( $place['price'] ) ) . '" name="'.$key_input.'[array_places][' . $i . '][price]" /></td>
									</tr>';
								}
							}
						?>
						</tbody>
						<tfoot>
							<tr>
								<th colspan="7"><a href="#" class="add button"><?php _e( '+ Add Place', 'gowoo' ); ?></a> <a href="#" class="remove_rows button"><?php _e( 'Remove selected place(s)', 'gowoo' ); ?></a> <a href="#" class="remove_all button"><?php _e( 'Remove all places', 'gowoo' ); ?></a></th>
							</tr>
						</tfoot>
					</table>
				</div>
				<div id="form_import" style="<?php echo $display_import; ?>">
					<fieldset>
						<legend class="screen-reader-text"><span><?php _e('Import places','gowoo'); ?></span></legend>

						<p><?php printf(__('You can import TXT or CSV files with the following structure: COD_COUNTRY:COD_STATE, FIRST_ZONE, SECOND_ZONE, PRICE (<a href="%s">Download Example</a>). Remember that if you use this option, it will replace the other.','gowoo'),plugins_url('/example-data.csv',__FILE__)); ?></p>

						<br /><br />

						<input class="input-text regular-input" type="file" name="<?php echo $key_input; ?>_places_import" id="places_import" />

						<?php $value_url_import = isset($this->place_details['url_import'])?$this->place_details['url_import']:''; ?>
						<input type="hidden" name="<?php echo $key_input; ?>[url_import]" value="<?php echo $value_url_import; ?>" />

						<label for="woocommerce_gowoo_shiplace_select2_lib">
							<input class="" type="checkbox" name="<?php echo $key_input; ?>[check_utf8]" id="<?php echo $key_input; ?>_check_utf8" style="" value="1" checked="checked"> <?php _e('Use utf8_encode (for &ntilde; or accents)','gowoo'); ?>
						</label>

						<p class="description">
						<?php
							if( $this->place_details['select_places'] == 'form_import' )
								printf(__('Currently there are <b>%s rows</b> loaded and you can <a href="%s" title="download">download this file</a>.','gowoo'),count($this->place_details['array_places']),$this->place_details['url_import']);
							else
								_e('Currently no data loaded','gowoo');
						?>
						</p>
						<br />
					</fieldset>
				</div>

				<table class="widefat wc_input_table">
					<tr>
						<td colspan="5"><h4><?php _e('Default Values','gowoo'); ?></h4></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td colspan="2"><input type="text" name="<?php echo $key_input; ?>[default_label]" value="<?php echo isset($this->place_details['default_label']) ? esc_attr( wp_unslash( $this->place_details['default_label'] ) ) : ''; ?>" placeholder="<?php _e('Default Label','gowoo'); ?>" /></td>
						<td colspan="2"><input type="text" name="<?php echo $key_input; ?>[default_price]" value="<?php echo isset($this->place_details['default_price']) ? esc_attr( wp_unslash( $this->place_details['default_price'] ) ) : ''; ?>" placeholder="<?php _e('Default Price','gowoo'); ?>" /></td>
					</tr>
				</table>

				<br /><br />
				
				<ul>
					<li><a href="https://goo.gl/3n4z3G" target="_blank" title="oficial documentation"><?php _e('You can view the oficial documentation','gowoo'); ?></a></li>
					<li><a href="https://goo.gl/IdP3YI" target="_blank" title="tips" ><?php _e('Or you read the tips that you can do with this plugin','gowoo'); ?></a></li>
				</ul>

			</td>
		</tr>

		<script type="text/javascript">
			jQuery(function() {

				if( jQuery('#wc-backbone-modal-dialog' ).is(':visible') ) {
					jQuery('#gowoo_hidden_view').val(0);
					jQuery('.gowoo_setting_places').hide();
					jQuery('.gowoo_setting_places').parent().append('<tr><th colspan="2" style="text-align: center;"><a class="text-center" href="admin.php?page=wc-settings&amp;tab=shipping&amp;instance_id=<?php echo $this->instance_id; ?>"><?php _e("View the rest of the configuration","gowoo") ?></a></th></tr>');
				}

				jQuery('input.select_places').click( function() {
					var form_value = jQuery(this).val();
						
					switch(form_value) {
						case 'form_manual' : jQuery('#form_import').fadeOut('fast'); break;
						case 'form_import' : jQuery('#form_manual').fadeOut('fast'); break;
					}

					jQuery('#'+form_value).fadeIn('fast');
				});

				jQuery('#form_manual').on( 'click', 'a.add', function(){
					var size = jQuery('#form_manual').find('tbody .place').size();
						jQuery('<tr class="place">\
							<td class="sort"></td>\
							<td>\
								<select name="<?php echo $key_input; ?>[array_places][' + size + '][cod_country]">\
									<?php WC()->countries->country_dropdown_options($base_country,$base_state,true); ?>\
								</select>\
							</td>\
							<td><input type="text" name="<?php echo $key_input; ?>[array_places][' + size + '][first_level]" /></td>\
							<td><input type="text" name="<?php echo $key_input; ?>[array_places][' + size + '][second_level]" /></td>\
							<td><input type="text" name="<?php echo $key_input; ?>[array_places][' + size + '][price]" /></td>\
							</tr>').appendTo('#form_manual table tbody');
						return false;
				});

				jQuery('#form_manual').on( 'click', 'a.remove_all', function(){
					jQuery('#form_manual table.wc_input_table tbody tr').each(function() {
						jQuery( this ).addClass( 'current' );
					});

					jQuery( 'a.remove_rows' ).trigger( 'click' );

					return false;
				});
			});
		</script>
		<?php
		return ob_get_clean();
	}


	function label_when_zero($label, $method) {
		if( $method->cost == 0 )
			return $method->label;
		else
			return $label;
	}


	function validate_place_details_field($key, $array_value) {

		if( isset($_POST['woocommerce_gowoo_shiplace_hidden_view']) && $_POST['woocommerce_gowoo_shiplace_hidden_view'] == 1 ) {

			$places = array();
			$array_save = array();
			$select_upload_places = wc_clean($_POST['woocommerce_gowoo_shiplace_place_details']['select_places']);

			if( $select_upload_places == 'form_import' ) { //Import File

				if ( isset( $_FILES['woocommerce_gowoo_shiplace_place_details_places_import']['error'] ) &&
						$_FILES['woocommerce_gowoo_shiplace_place_details_places_import']['error'] == 0 ) {

					$max_file_size = 2097152; //2Mb
					$array_keys = array('cod_country','first_level','second_level','second_key','price');
					$goship_tmp  = $_FILES['woocommerce_gowoo_shiplace_place_details_places_import']['tmp_name'];
					$goship_name = $_FILES['woocommerce_gowoo_shiplace_place_details_places_import']['name'];
					$goship_type = $_FILES['woocommerce_gowoo_shiplace_place_details_places_import']['type'];
					$goship_size = $_FILES['woocommerce_gowoo_shiplace_place_details_places_import']['size'];
			
					if($goship_size > $max_file_size) {
						$this->errors[] = __('Error : The file weighs more than the maximum allowed (2Mb)','gowoo');
						return;
					}

					//	Open the CVS file
					if (($content_csv = fopen($goship_tmp, "r")) !== FALSE) { $i=0;

    					while (($array_row = fgetcsv($content_csv, 1000, ",")) !== FALSE) { $i++;

        					if( count($array_row) != 4 ) {
        						$this->errors[] = sprintf(__('Error : The line %s has more than 4 columns','gowoo'),$i);
        						return;
        						break;
        					}

        					if(!empty($array_row[0])) {
		       					$array_row[4] = $array_row[3];
        						$array_row[3] = $i;

        						$array_aux[] = $array_row;

        						if( isset($_POST['woocommerce_gowoo_shiplace_place_details']['check_utf8']) &&
        							$_POST['woocommerce_gowoo_shiplace_place_details']['check_utf8'] == 1 )
        							$array_save[] = array_map( 'utf8_encode', array_combine($array_keys,$array_row) );
        						else
        							$array_save[] = array_combine($array_keys,$array_row);
        					}
    					}

    					/*while (($buffer = fgets($content_csv, 1000)) !== false) { $i++;

    						update_option('xpollo3',print_r(mb_detect_encoding($buffer),true));
							$array_row = explode(',', iconv(mb_detect_encoding($buffer, mb_detect_order(), true), "UTF-8", $buffer));

							update_option('xpollo4',print_r($array_row,true));

							if( count($array_row) != 4 ) {
        						$this->errors[] = sprintf(__('Error : The line %s has more than 4 columns','gowoo'),$i);
        						return;
        						break;
        					}

		       				$array_row[4] = $array_row[3];
        					$array_row[3] = $i;
        					$array_save[] = array_combine($array_keys,$array_row);
    					}*/

    					fclose($content_csv);

    					//copy csv to upload files
    					$upload_overrides = array('test_form' => false);
    					$movefile = wp_handle_upload($_FILES['woocommerce_gowoo_shiplace_place_details_places_import'],$upload_overrides);

    					if ( $movefile && ! isset( $movefile['error'] ) ){
    						$array_value['url_import'] = $movefile['url'];
        				} else {
        					$this->errors[] = sprintf(__('The file %s could not be saved','gowoo'),$goship_name);
        					return;
        				}
					}
				} else {
					$array_aux = $this->get_option( 'place_details', array('select_places' => 'form_manual'));
					unset($array_aux['array_places']['default_label']);
					unset($array_aux['array_places']['default_price']);
					$array_save = $array_aux['array_places'];
				}

			} else { //Manual

				if ( isset( $_POST['woocommerce_gowoo_shiplace_place_details']['array_places'] ) ) {

					foreach($_POST['woocommerce_gowoo_shiplace_place_details']['array_places'] as $i => $array_fields) {
						$cod_country 	= wc_clean( $array_fields['cod_country'] );
						$first_level	= wc_clean( $array_fields['first_level'] );
						$second_level 	= wc_clean( $array_fields['second_level'] );
						$price 			= wc_clean( $array_fields['price'] );

						if ( ! isset( $cod_country ) ) {
							continue;
						}
					
						$array_save[] = array(		
								'cod_country'   => $cod_country,
								'first_level'	=> $first_level,
								'second_level'	=> $second_level,
								'second_key'	=> $i+1,
								'price'			=> $price
						);
					}
				}
			}

			if(is_array($array_save) && count($array_save) > 0 )
				$array_value['array_places'] = $array_save;

		} else
			$array_value = $this->get_option( 'place_details', array('select_places' => 'form_manual'));

		return $array_value;
	}

	
	function is_available( $package = array() ) {

		// Enabled logic
		$is_available = true;

		return apply_filters( 'woocommerce_shipping_'.$this->id.'_'.$this->instance_id.'_is_available', $is_available, $package );
	}

	
	function calculate_shipping( $package = array() ) {

		if($_POST && !is_cart()) {

			$this->label_first 	= $this->get_option( 'label_first', __( 'Province', 'gowoo' ) );
			$this->label_second = $this->get_option( 'label_second', __( 'District', 'gowoo' ) );
			$this->place_details = $this->get_option( 'place_details', array('select_places' => 'form_manual'));

			if( isset($_POST['post_data']) ) { //For Shipping Ajax

				$this->shipdata['country'] = $_POST['s_country'];
				$this->shipdata['state'] = $_POST['s_state'];

				$aux1_post_data = explode('&',$_POST['post_data']);

				foreach($aux1_post_data as $aux1_var_data) {
					$aux2_post_data = explode('=',$aux1_var_data);
					$aux_gowoo_place[$aux2_post_data[0]] = $aux2_post_data[1];
				}

				if( isset($aux_gowoo_place['ship_to_different_address']) && $aux_gowoo_place['ship_to_different_address']==1 )
					$key_gowoo_place = $aux_gowoo_place['shipping_gowoo_place'];
				else
					$key_gowoo_place = $aux_gowoo_place['billing_gowoo_place'];

				//
				if( isset($_POST['shipping_method'][0]) ) {
					$array_ship = explode(':',$_POST['shipping_method'][0]);
					$key_gowoo_place = $array_ship[0] == $this->id ? $key_gowoo_place : 0;
				}

			} else { //For Gateway Page

				if( isset($_POST['ship_to_different_address']) && $_POST['ship_to_different_address']==1 ) {
					$this->shipdata['country'] = $_POST['shipping_country'];
					$this->shipdata['state'] = $_POST['shipping_state'];
					$key_gowoo_place = $_POST['shipping_gowoo_place'];

				} else {
					$this->shipdata['country'] = $_POST['billing_country'];
					$this->shipdata['state'] = $_POST['billing_state'];
					$key_gowoo_place = $_POST['billing_gowoo_place'];
				}
			}

			//$array_var_places = explode('_',$value_gowoo_place);
			//$array_var_places[0] is zone1 (first_level)
			//$array_var_places[1] is zone2 (second_level)

			//verify if the country have states
			if ( $states = WC()->countries->get_states( $this->shipdata['country'] ) )
				$without_states = 0;
			else
				$without_states = 1;

			// Search us
			//foreach($this->place_details as $places) {
			if( isset($this->place_details['array_places']) && is_array($this->place_details['array_places']) ) {

				foreach($this->place_details['array_places'] as $places) {
				
					$array_var_country = explode(':',$places['cod_country']);

					if( $this->shipdata['country'] == $array_var_country[0] &&
						( $without_states || $this->shipdata['state'] == $array_var_country[1] ) &&
						$key_gowoo_place == $places['second_key'] ) {

						$this->shipdata['found'] = 'in list';
						$this->shipdata['level2_key'] = $places['second_key'];
						$this->shipdata['level1'] = $places['first_level'];
						$this->shipdata['level2'] = $places['second_level'];
						$this->shipdata['label'] = $this->title.' ('.$places['second_level'].')';
						$this->shipdata['price'] = $places['price'];

						break;
					}
				}
			}

			/********************
				DEFAULT VALUES
			*********************/
			if( !$this->shipdata['found'] ) {
				$this->shipdata['label'] = $this->title.' ('.(!empty($this->place_details['default_label']) ? $this->place_details['default_label'] : __('Empty default label','gowoo')).')';
				$this->shipdata['price'] = !empty($this->place_details['default_price']) ? $this->place_details['default_price'] : 0;
				$this->shipdata['found'] = 'default';
			}

		} else {
			$this->shipdata['label'] = $this->title;
			$this->shipdata['price'] = 0;
			$this->shipdata['found'] = 'not found';
		}

		/*	HOOK	*/
		$this->shipdata = apply_filters( 'woocommerce_shipping_'.$this->id.'_'.$this->instance_id.'_calculate', $this->shipdata, $package );

		$args = array(
				'label' => $this->shipdata['label'],
				'package'    => $package,
				'cost' 	=> $this->shipdata['price'],
				'calc_tax' => 'per_order'
		);

		$this->add_rate( $args );
	}
}	
?>
