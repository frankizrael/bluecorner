<?php
/*
Plugin Name: WooCommerce Shipping Price by Place
Plugin URI: https://www.letsgodev.com/product/woocommerce-shipping-price-by-place/
Description: This is a shipping method where you can specify the cities of the región and give a different price for each location. This price is updated when you choose a location.
Version: 2.2.1
Author: GoPymes SAC
Author URI: https://www.letsgodev.com/
Developer: Alexander Gonzalesc
Developer URI: http://blog.gopymes.pe/
Text Domain: woocommerce-extension
Requires at least: 4.0.1
Tested up to: 4.7.2
Stable tag: 4.7
WC requires at least: 2.6
WC tested up to: 3.0.0
*/


define('WOOSHIPP_API_URL', 'https://www.letsgodev.com/index.php');
define('WOOSHIPP_PRODUCT_ID', 'PLWOOSHIP1');
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
define('WOOSHIPP_INSTANCE', str_replace($protocol, "", get_bloginfo('wpurl')));
define('WOOSHIPP_EMAIL_SUPPORT','support@letsgodev.com');
define('WOOSHIPP_VERSION', '2.2.1');


/* WooCommerce fallback notice. */
function gowoo_shiplace_notice() {
	echo '<div class="error"><p>' . sprintf( __( 'Plugin WooCommerce Shipping Price by Place depends on the last version of %s to work!', 'gowoo' ), '<a href="http://wordpress.org/extend/plugins/woocommerce/">WooCommerce</a>' ) . '</p></div>';
}


/*	Adds custom settings url in plugins page	*/
function gowoo_shiplace_links( $links ) {
	$settings = array(
		'zone' => sprintf('<a href="%s" target="_blank">%s</a>',
				admin_url('admin.php?page=wc-settings&tab=shipping'),
				__( 'Setting Zone', 'gowoo' )
			)
		);

	return array_merge( $settings, $links );
}
add_filter( 'plugin_action_links_'.plugin_basename( __FILE__ ), 'gowoo_shiplace_links' );


function gowoo_shiplace_setting_external_link($links, $file) {
	if ( $file == 'woocommerce-shipping-price-by-place/index.php' ) {
        
        $row_meta = array(
        			'docs' => sprintf('<a href="%s" target="_blank" title="%s">%s</a>',esc_url('https://www.letsgodev.com/documentation/docs-woocommerce-shipping-price-by-place/'), 'Woocommerce Shipping Price by Place' ,__('Documentation','gowoo')),
                	'support' => sprintf('<a href="%s" target="_blank" title="%s">%s</a>',esc_url('https://www.letsgodev.com/contact/'), 'Woocommerce Shipping Price by Place' ,__('Support','gowoo')),
                	'buy' => sprintf('<a href="%s" target="_blank" title="%s">%s</a>',esc_url('https://www.letsgodev.com/'), 'Woocommerce Shipping Price by Place' ,__('More Premiun Plugins','gowoo')),
            );

        return array_merge( $links, $row_meta );
    }

    return (array) $links;
}
add_filter( 'plugin_row_meta', 'gowoo_shiplace_setting_external_link', 10, 2 );






require_once plugin_dir_path( __FILE__ ).'/licenses.class.php';
$licenses = new wooshiprice_licenses();	


$settings = get_option('gowoo_shiprice_license');

if( isset($settings['is_active']) && $settings['is_active'] == 1 ) {
	
	/*	Load functions	*/
	function gowoo_shiplace_load() {
		if ( ! class_exists( 'WC_Shipping_Method' ) ) {
			add_action( 'admin_notices', 'gowoo_shiplace_notice' );
			return;
		}

		/*	Add the class	*/
		function gowoo_shiplace_add( $methods ) {
			require_once plugin_dir_path( __FILE__ ) . 'gowoo-method-shipprice-by-place.php';
		
			$methods['gowoo_shiplace'] = 'WC_Shipping_Price_by_Place';
			return $methods;
		}
		add_filter( 'woocommerce_shipping_methods', 'gowoo_shiplace_add' );
	
		/********************
			LOCALIZATION
		*********************/
		load_plugin_textdomain( 'gowoo', false, dirname( plugin_basename( __FILE__ ) ).'/languages/' );
	}
	add_action( 'plugins_loaded', 'gowoo_shiplace_load', 0 );



	/***********************
		CONTROLLER METHOD
	************************/
	require_once plugin_dir_path( __FILE__ ) . 'gowoo-controller-shipprice-by-place.php';
	$gowoo_shipplace = new gowoo_controller_shipprice_by_place();
}
?>