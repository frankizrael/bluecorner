jQuery( function( $ ) {

	var country, state, prefix, levelid, lastid, refresh=1, shippmethod, instance_id, onlycountry=0;

	/* INI */
	gowoo_hidden_field();


	$(document.body).on('updated_checkout', function(){

		if ( typeof wc_country_select_params === 'undefined' ) {
			return false;
		}

		set_varship();


		/* State/Country select boxes */
		var states_json = wc_country_select_params.countries.replace( /&quot;/g, '"' );
		var states_list = $.parseJSON( states_json );

		if ( !states_list[ country ] || $.isEmptyObject( states_list[ country ] ) ) {
			onlycountry=1;
		} else
			onlycountry=0;


		if( shippmethod == 'gowoo_shiplace' && refresh == 1 ) {

			var options = '';
			state = onlycountry==1 ? '' : state;

			$.getJSON( gowoojson.url+'?instance_id='+instance_id+'&cod_country='+country+'&cod_state='+state, function( data ) {

				//console.log(gowoojson.url+'?instance_id='+instance_id+'&cod_country='+country+'&cod_state='+state);
 				//options = options + '<select name="'+levelid+'" id="'+levelid+'">';

  				if( data.places_details.length == 0 ) { //ifempty
  					options = options + '<option value="0">'+data.places_info.label_textdefault+'</option>';
  					
    			} else {
    				options = options + '<option value="">'+data.places_info.label_choise+'</option>';
    				$.each( data.places_details, function( ind_first, val_first ) {
	  					options = options + '<optgroup label="'+val_first.title_first+'">';

	  					$.each( val_first.level, function( key_second, val_second ) {
  							options = options + '<option value="'+val_second.key_second+'">'+val_second.title_second+'</option>';
  						});

  						options = options + '</optgroup>';
	    			});
    			}
    			//options = options + '</select>';

    			$('#'+levelid+'_field label:first-child').html(data.places_info.label_first+'/'+data.places_info.label_second);
    			$('#'+levelid).empty().append(options);

				//Show the select
				$('#'+levelid+'_field').slideDown('fast');

				// Select2 Library
 				if(data.places_info.select2_lib == 'yes') {
					$('#billing_gowoo_place').select2({allowClear: true});
					$('#shipping_gowoo_place').select2({allowClear: true});
				}
  			});
		}

		//if( (state=='' || shippmethod!='gowoo_shiplace') && $('#'+levelid+'_field').is(':visible') ) $('#'+levelid+'_field').slideUp('fast');
	});

	
	function set_varship() {
		
		//if( $('#ship-to-different-address-checkbox').is(':checked') ) {
		if( $('input[name="ship_to_different_address"]').is(':checked') ) {
			prefix = 'shipping';
			lastid = 'billing_gowoo_place';
		} else {
			prefix = 'billing';
			lastid = 'shipping_gowoo_place';
		}

		country = $('#'+prefix+'_country').val();
		state = $('#'+prefix+'_state').val();
		levelid = prefix+'_gowoo_place';

		var valueship;
		if( $('input[name="shipping_method[0]"]').is(':radio') )
			valueship = $('input[name="shipping_method[0]"]:checked').val();
		else {
			if( $('select[name="shipping_method[0]"]').is('select') )
				valueship = $('select[name="shipping_method[0]"]').val();
			else
				valueship = $('input[name="shipping_method[0]"]').val();
		}

		var arrayship = valueship.split(":");

		shippmethod = arrayship[0];
		instance_id = arrayship[1];

		return true;
	}

	function gowoo_hidden_field() {
		if( $('#billing_gowoo_place_field').is(':visible') ) $('#billing_gowoo_place_field').slideUp('fast');
		if( $('#shipping_gowoo_place_field').is(':visible') ) $('#shipping_gowoo_place_field').slideUp('fast');

		return true;
	}


	/***************************
		CLICK SHIP CHECKBOX
	****************************/
	$( document.body ).on( 'click', '#ship-to-different-address-checkbox', function() {
		refresh = 1;

		// if the field is visible then hidden it
		setTimeout(gowoo_hidden_field, 500);
	});

	/*******************************
		CLICK METHOD RADIO/SELECT
	********************************/
	$( document.body ).on( 'click, change', 'input[name="shipping_method[0]"], select[name="shipping_method[0]"]', function() {
		refresh = 1;

		// if the field is visible then hidden it
		gowoo_hidden_field();
	});
	

	/***************************
		CHANGE COUNTRY SELECT
	****************************/
	$( document.body ).on( 'change', '#billing_country, #shipping_country', function() {
		refresh = 1;

		// if the field is visible then hidden it
		gowoo_hidden_field();
	});

	/************************
		CHANGE CITY SELECT
	*************************/
	$( document.body ).on( 'change', '#billing_state, #shipping_state', function() {
		refresh = 1;

		// if the field is visible then hidden it
		gowoo_hidden_field();

		$( document.body ).trigger( 'update_checkout' );
	});


	$( document.body ).on( 'change', '#billing_gowoo_place, #shipping_gowoo_place', function() {
		refresh = 0;
	});

	
});