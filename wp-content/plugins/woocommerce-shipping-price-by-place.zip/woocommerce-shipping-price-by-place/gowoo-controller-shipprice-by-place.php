<?php
class gowoo_controller_shipprice_by_place {

	protected $varmethod;
	protected $array_shiplaces = array();
	
	function __construct() {

		delete_transient( 'shipping-transient-version' );

		//JSON URL			
		add_action('init',array($this,'add_endpoint'));
		add_filter('request',array($this,'json_404'));
		add_action('template_redirect',array($this,'json_rewrite'));

		add_filter('woocommerce_checkout_fields' , array($this, 'checkout_add_fields' ));
		add_action('wp_enqueue_scripts',array($this, 'addscripts' ));
		//add_filter('woocommerce_form_field_select','form_field', 10, 2);

		add_filter('woocommerce_checkout_fields',array($this,'add_require_field'),10,1);

		// Let's add the field zone of email format
		//EMAIL TEMPLATE
		add_filter('woocommerce_localisation_address_formats',array($this,'add_field_format'),10,1);
		add_filter('woocommerce_formatted_address_replacements',array($this,'add_field_goowooship'),10,2);
		add_filter('woocommerce_order_formatted_billing_address',array($this,'add_billing_address'),10,2);
		add_filter('woocommerce_order_formatted_shipping_address',array($this,'add_shipping_address'),10,2);
		add_filter('woocommerce_admin_billing_fields',array($this,'add_admin_checkout_address'),10,1);
		add_filter('woocommerce_admin_shipping_fields',array($this,'add_admin_checkout_address'),10,1);

		//save data in postmeta
		add_action('woocommerce_checkout_update_order_meta',array($this,'update_meta_field'),10,2);
	}


	function addscripts() {

		if(is_checkout()) {

			wp_enqueue_script('gowoo-ship', plugins_url('/gowoo_ajax_shipprice_by_place.js',__FILE__), array('jquery','wc-checkout'),false,true);
			wp_localize_script('gowoo-ship', 'gowoojson', array('url' => home_url('json_goshiplace/') ) );
		}
	}

	function add_endpoint() {
		add_rewrite_endpoint( 'json_goshiplace', EP_ROOT );
	}

	function json_404($vars) {
		if(isset($vars['json_goshiplace']))
			$vars['json_goshiplace'] = true;

		return $vars;
	}

	function json_rewrite() {

		if( is_home() && get_query_var('json_goshiplace') && isset($_GET['instance_id']) && isset($_GET['cod_country']) && isset($_GET['cod_state']) ) {

			$this->set_data_shipplace($_GET['instance_id']);

			if( is_array($this->array_shiplaces) && count($this->array_shiplaces) > 0 ) {

				$array_out['places_info'] = array(
												'select2_lib' => isset($this->array_shiplaces['select2_lib']) ? $this->array_shiplaces['select2_lib'] : 'no',
												'requifield' => isset($this->array_shiplaces['requifield']) ? $this->array_shiplaces['requifield'] : 'yes',
												'label_first' => isset($this->array_shiplaces['label_first']) ? $this->array_shiplaces['label_first'] : __('Empty first label','gowoo'),
												'label_second' => isset($this->array_shiplaces['label_second']) ? $this->array_shiplaces['label_second'] : __('Empty second label','gowoo'),
												'default_label' => isset($this->array_shiplaces['place_details']['default_label']) ? $this->array_shiplaces['place_details']['default_label'] : __('Empty default label','gowoo'),
												'default_price' => isset($this->array_shiplaces['place_details']['default_price']) ? $this->array_shiplaces['place_details']['default_price'] : 0,
												'label_textdefault' => sprintf(__('There is not %s/%s','gowoo'),$this->array_shiplaces['label_first'],$this->array_shiplaces['label_second']),
												'label_choise' => sprintf(__('Choise %s/%s','gowoo'),$this->array_shiplaces['label_first'],$this->array_shiplaces['label_second'])
											);

				$array_out['places_details'] = $this->get_place_details($_GET['cod_country'],$_GET['cod_state']);

				$array_out = apply_filters('woocommerce_shipping_gowoo_shiplace_'.$_GET['instance_id'].'_settings',$array_out);

				header('Content-Type: text/plain');
				echo json_encode($array_out);
				exit();
			}
		}
	}


	function checkout_add_fields( $fields ) {

		$method_allship = WC()->session->get('chosen_shipping_methods') !== null ? WC()->session->get('chosen_shipping_methods') : ':';
		$method_arrayship = explode(':',$method_allship[0]);
		$this->set_data_shipplace($method_arrayship[1]);
		
		if( $method_arrayship[0] == 'gowoo_shiplace' && count($this->array_shiplaces)>0 ) {

			$label_places = $this->array_shiplaces['label_first'].' / '.$this->array_shiplaces['label_second'];
			$type = 'select';

			$base_country = isset($_POST['country']) ? sanitize_text_field($_POST['country']) : '';
			$base_state = isset($_POST['state']) ? sanitize_text_field($_POST['state']) : '';

			$array_out = array('' => sprintf(__( 'Choise %s', 'gowoo' ),$label_places ));

		} else {
			$label_places = __('Shipping Price by Place Field','gowoo');
			$array_out = array('' => __( 'Choise a place', 'gowoo' ));
			$type = 'select';
		}

		$fields['billing']['billing_gowoo_place'] = array(
				'label'     => $label_places,
				'type'		=> $type,
				'options'	=> $array_out,
				'required'  => 0,
				'class'     => array('form-row-wide address-field update_totals_on_change'),
				'clear'     => true
   		);

   		$fields['shipping']['shipping_gowoo_place'] = array(
				'label'     => $label_places,
				'type'		=> $type,
				'options'	=> $array_out,
				'required'  => 0,
				'class'     => array('form-row-wide address-field update_totals_on_change'),
				'clear'     => true
   		);

		return apply_filters('gowoo_checkout_fields',$fields);
	}


	function add_require_field($checkout) {

		$array_shipping_current = WC()->session->get( 'chosen_shipping_methods' );
		$array_shipping_method = explode(':',$array_shipping_current[0]);

		$this->set_data_shipplace($array_shipping_method[1]);

		if(is_array($array_shipping_method) && $array_shipping_method[0]=='gowoo_shiplace' && $this->array_shiplaces['requifield']=='yes') {

			if(isset($_POST['ship_to_different_address'])) {
				$checkout['shipping']['shipping_gowoo_place']['required']=1;
				$checkout['billing']['billing_gowoo_place']['required']=0;
			} else {
				$checkout['billing']['billing_gowoo_place']['required']=1;
				$checkout['shipping']['shipping_gowoo_place']['required']=0;
			}
		}

		return $checkout;
	}


	function set_data_shipplace( $instance_id = 0 ) {
		global $wpdb;

		$query_shiplaces = $wpdb->get_col( 'SELECT option_value FROM '.$wpdb->options.' WHERE option_name LIKE "woocommerce_gowoo_shiplace_%_settings"' );
		$option_shiplaces = array_map('maybe_unserialize',$query_shiplaces);

		foreach($option_shiplaces as $array_fields) {
			if( $instance_id == $array_fields['instance_id'] ) {
				$this->array_shiplaces = $array_fields;
				break;
			}
		}
	}


	function get_place_details($param_country, $param_state) {
		
		$array_out = array();

		if( is_array($this->array_shiplaces['place_details']['array_places']) && count($this->array_shiplaces['place_details']['array_places']) > 0 ) {

			$array_first_level = $array_second_level = array();
			$i = 0;
				
			foreach($this->array_shiplaces['place_details']['array_places'] as $places) {
				$array_var_country = explode(':',$places['cod_country']);
				$array_var_country[1] = isset($array_var_country[1]) ? $array_var_country[1] : '';
					
				//If is the country and the state
				if( $param_country == $array_var_country[0] && $param_state == $array_var_country[1] ) {

					if( !in_array($places['first_level'],$array_first_level) ) {
						$i++;
						$array_first_level[ $i ] = $places['first_level'];
					}

					$array_second_level[ $i ][ $places['second_key'] ] = $places['second_level'];
				}
			}
		}

		$i = 0;
		foreach($array_first_level as $key_first_level => $value_first_level) {
			$array_out[$i] = array('title_first' => $value_first_level);

			foreach( $array_second_level[$key_first_level] as $key_second_level => $value_second_level )
				$array_out[$i]['level'][] = array('title_second' => $value_second_level, 'key_second' => $key_second_level );

			$i++;
		}

		return $array_out;
	}


	function form_field($field, $key) {

		if( in_array($key, array('billing_gowoo_place','shipping_gowoo_place')) ) {
			$field = str_replace('<p','<p style="display:none;"',$field);
		}

		return $field;
	}


	/*************************************************************
		INI: FIELD gowooship in EMAIL TEMPLATE and ORDER DETAIL
	**************************************************************/
	function add_field_goowooship($array_billing, $args) {

		extract( $args );
		$array_billing['{gowooship1}'] = isset($gowooship1) ? $gowooship1 : '';
		$array_billing['{gowooship2}'] = isset($gowooship2) ? $gowooship2 : '';

		return $array_billing;
	}


	function add_field_format($array_format) {

		foreach($array_format as $key => $value)
			$array_format[$key].="\n{gowooship1}\n{gowooship2}";

		return $array_format;
	}


	function add_billing_address($array_address,$order) {

		if( !empty( $order->billing_gowoo_place ) && is_numeric( $order->billing_gowoo_place ) ) {
			$array_address['gowooship1'] = $order->billing_gowoo_first;
			$array_address['gowooship2'] = $order->billing_gowoo_second;
		}

		return $array_address;
	}


	function add_shipping_address($array_address,$order) {

		if( !empty( $order->shipping_gowoo_place ) && is_numeric( $order->shipping_gowoo_place ) ) {
			$array_address['gowooship1'] = $order->shipping_gowoo_first;
			$array_address['gowooship2'] = $order->shipping_gowoo_second;
		}

		return $array_address;
	}


	function add_admin_checkout_address($array_address) {

		$array_address['gowoo_first'] = array('label' => __('Shipping First','gowoo'), 'show' => false);
		$array_address['gowoo_second'] = array('label' => __('Shipping Second','gowoo'), 'wrapper_class' => 'last', 'show' => false);

		return $array_address;
	}

	// save variable in postmeta table
	function update_meta_field($order_id, $posted) {

		$method_shipping = explode(':',$posted['shipping_method'][0]);

		if( $method_shipping[0] == 'gowoo_shiplace' ) {

			if($posted['ship_to_different_address'] == 1) { //shipping

				$key_address = 'shipping';
				$key_gowooship = $posted['shipping_gowoo_place'];

			} else { //billing

				$key_address = 'billing';
				$key_gowooship = $posted['billing_gowoo_place'];
			}


			$this->set_data_shipplace($method_shipping[1]);

			if( is_array($this->array_shiplaces['place_details']['array_places']) ) {

				foreach($this->array_shiplaces['place_details']['array_places'] as $array_places) {
					
					if( $array_places['second_key'] == $key_gowooship ) {

						$first_level = $array_places['first_level'];
						$second_level = $array_places['second_level'];

						update_post_meta( $order_id, '_'.$key_address.'_gowoo_first' , $first_level );
						update_post_meta( $order_id, '_'.$key_address.'_gowoo_second' , $second_level );
					}
				}
			}
		}
	}

	/********************************************
		FIN: FIELD gowooship in EMAIL TEMPLATE
	*********************************************/
}
?>