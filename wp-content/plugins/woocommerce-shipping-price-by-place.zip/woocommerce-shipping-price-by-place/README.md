# [WooCommerce Shipping Price by Place](http://shop.gopymes.pe/product/woocommerce-shipping-price-by-place/)

Welcome to the WooCommerce Shipping Price by Place repository on Gitlab. This is a shipping method where you can specify the cities of the región and give a different price for each location. This price is updated when you choose a location. We recommend  write the [Documentation Online](http://shop.gopymes.pe/documentation/docs-woocommerce-shipping-price-by-place/) to stay up to date about everything happening in the project. You can also [follow @gopymes](https://twitter.com/gopymes) on Twitter for the latest development updates.

## Documentation
* [(English) Online Documentation](http://shop.gopymes.pe/documentation/docs-woocommerce-shipping-price-by-place/)
* [(Spanish) Online Documentation](http://blog.gopymes.pe/wordpress/plugin-wp-para-elegir-distritos-de-envio-en-woocommerce/)

* [(English) Tips](http://shop.gopymes.pe/tips/4-tips-plugin-woocommerce-shipping-price-place/)


## Support
If you need support, please send us email to support[at]gopymes.pe