<?php
class wooshiprice_licenses {

    protected $slug = 'woocommerce-shipping-price-by-place';
    protected $plugin = 'woocommerce-shipping-price-by-place/index.php';

	function __construct() {
		add_action('admin_init', array($this,'verify'));

        // Take over the update check
        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_update'));

        // Take over the Plugin info screen
        add_filter('plugins_api', array($this, 'plugins_api_call'), 10, 3);
	}


	function verify() {

		if( isset($_POST['gowoo_shiprice_license_key']) && !$this->activate_license($_POST['gowoo_shiprice_license_key']) )
			add_action('admin_notices', array($this, 'get_license_html'));
		elseif(!$this->is_active()) {
			add_action('admin_notices', array($this, 'get_license_html'));
		}
	}


	function is_active() {
		
		$is_active = get_transient('gowoo_shiprice_is_active_license');
		$settings = get_option('gowoo_shiprice_license');

		if( !isset($settings['license_key']) || empty($settings['license_key']) ) {
			$is_active = 0;

		} elseif(!isset($is_active) || empty($is_active) ) {

			$args = array(
            	        'woo_sl_action'		=> 'status-check',
                	    'licence_key'		=> $settings['license_key'],
                    	'product_unique_id'	=> WOOSHIPP_PRODUCT_ID,
                    	'domain'			=> WOOSHIPP_INSTANCE
                	);
		
			$request_uri    = WOOSHIPP_API_URL . '?' . http_build_query( $args );
			$data           = wp_remote_get( $request_uri );

			if(is_wp_error( $data ) || $data['response']['code'] != 200) {

				if( $settings['is_active'] == 1 )
					$is_active = 1;
				else
					$is_active = 0;

        		wp_mail( WOOSHIPP_EMAIL_SUPPORT, sprintf(__('Server %s is down right (from %s)','gowoo'),WOOSHIPP_API_URL,site_url()), print_r($data,true) );
    		} else {

				$data_body = json_decode($data['body']);

				if(isset($data_body[0]->status)) {

        			if($data_body[0]->status == 'success' && $data_body[0]->status_code == 's205') {
             			
             			$is_active = 1;
             			set_transient('gowoo_shiprice_is_active_license', $is_active, 12 * HOUR_IN_SECONDS);
        			
        			} else {

        				//[status] => success [status_code] => s203 [message] => Licence Is Inactive
            			$is_active = 0;
            			$settings['is_active'] = 0;
            			$settings['license_key'] = '';

            			$this->error_title = __('There was a problem checking the license','gowoo');
        				$this->error_desc = print_r($data_body,true);
            		}
    			} else {
        			$is_active = 0;
        			$settings['is_active'] = 0;
        			$settings['license_key'] = '';

        			$this->error_title = __('There was a problem establishing a connection to the API server','gowoo');
    				$this->error_desc = print_r($data_body,true);
    			}
    		}

    		update_option('gowoo_shiprice_license', $settings);
		}

		return $is_active;
	}


    function activate_license($license_key) {

    	//Array ( [0] => stdClass Object ( [status] => error [status_code] => e113 [message] => Licence already active for test.gopymes.pe/general. If you lost track of it, you can manually de-activate it from your account. ) )

    	$settings = get_option('gowoo_shiprice_license');

		$args = array(
            	    'woo_sl_action'		=> 'activate',
                	'licence_key'		=> $license_key,
                    'product_unique_id'	=> WOOSHIPP_PRODUCT_ID,
                    'domain'			=> WOOSHIPP_INSTANCE
                );
		
		$request_uri    = WOOSHIPP_API_URL . '?' . http_build_query( $args );
		$data           = wp_remote_get( $request_uri );


		if(is_wp_error( $data ) || $data['response']['code'] != 200) {

			$is_active = 0;
			$settings['is_active'] = 0;
            $settings['license_key'] = '';
        	
        	$this->error_title = __('Server is down right. An email was sent to '.WOOSHIPP_EMAIL_SUPPORT,'gowoo');
        	$this->error_desc = print_r($data,true);

        	wp_mail( WOOSHIPP_EMAIL_SUPPORT, sprintf(__('Server %s is down right (from %s)','gowoo'),WOOSHIPP_API_URL,site_url()), print_r($data,true));
    	} else {

			$data_body = json_decode($data['body']);
			
			if( isset($data_body[0]->status) ) {
        		if($data_body[0]->status == 'success' && $data_body[0]->status_code == 's100') {
             		
             		$is_active = 1;
             		
             		$settings['is_active'] = 1;
             		$settings['license_key'] = $license_key;

    				set_transient('gowoo_shiprice_is_active_license', $is_active, 12 * HOUR_IN_SECONDS);
    				update_option('gowoo_shiprice_license', $settings);
    				wp_redirect($_SERVER['REQUEST_URI']);
    				exit;

        		} else {

        			$is_active = 0;
        			$settings['is_active'] = 0;
             		$settings['license_key'] = '';

        			$this->error_title = __('There was a problem activating the license','gowoo');
        			$this->error_desc = print_r($data_body,true);
            	}
    		} else {

    			$is_active = 0;
    			$settings['is_active'] = 0;
             	$settings['license_key'] = '';

    			$this->error_title = __('There was a problem establishing a connection to the API server','gowoo');
    			$this->error_desc = print_r($data_body,true);
    		}
    	}

    	update_option('gowoo_shiprice_license', $settings);

    	return $is_active;
    }


    function get_license_html() {
        // Open container
        $html = '<div class="update-nag" style="display: block;">';

        // Title
        $html .= '<h3 style="margin-top: 0.3em; margin-bottom: 0.6em;">' . __('Woocommerce Shipping Price by Place', 'gowoo') . '</h3>';

        // Description
        $html .= '<div style="margin-bottom: 0.6em; font-size: 13px;">' . __('Please enter your license code','gowoo') . '</div>';

        // Error
        if ( !empty($this->error_title) ) {
            $html .= '<div style="margin-bottom: 0.6em; font-size: 13px; color: red;">'.$this->error_title.'</div>';
            $html .= '<code>'.print_r($this->error_desc,true).'</code>';
        }

        // Open form
        $html .= '<form method="post" style="margin-bottom: 0.6em;">';

        // Field
        $html .= '<input type="text" name="gowoo_shiprice_license_key" value="" placeholder="' . __('License Code', 'gowoo') . '" style="width: 50%; margin-right: 10px;">';

        // Button
        $html .= '<button type="submit" class="button button-primary" title="' . __('Submit', 'gowoo') . '">' . __('Submit', 'gowoo') . '</button>';

        // Close form
        $html .= '</form>';

        // Note
        $html .= '<div><small><a href="https://www.letsgodev.com/documentation/where-do-i-find-my-license-code/" rel="noopener" target="_blank">' . __('Where do I find my License Code?', 'gowoo') . '</a></small></div>';

        // Close container
        $html .= '</div>';

        echo $html;
    }



    function check_update($checked_data) {
        
        if (empty($checked_data->checked) || !isset($checked_data->checked[$this->plugin]))
            return $checked_data;

        $request_string = $this->prepare_request('plugin_update');
        
        if($request_string === FALSE)
            return $checked_data;

        // Start checking for an update
        $request_uri = WOOSHIPP_API_URL . '?' . http_build_query( $request_string , '', '&');

        $data = wp_remote_get( $request_uri );

        if(is_wp_error( $data ) || $data['response']['code'] != 200)
            return $checked_data;

        $response_block = json_decode($data['body']);
 
        if(!is_array($response_block) || count($response_block) < 1) {
            return $checked_data;
        }

        //retrieve the last message within the $response_block
        $response_block = $response_block[count($response_block) - 1];

        $response = isset($response_block->message) ? $response_block->message : '';

        if (is_object($response) && !empty($response)) { // Feed the update data into WP update

            //include slug and plugin data
            $response->slug = $this->slug;
            $response->plugin = $this->plugin;
            $response->url = $response->homepage;

            $checked_data->response[$this->plugin] = $response;
        }

        return $checked_data;
    }



    public function prepare_request($action, $args = array()) {

        global $wp_version;

        $settings = get_option('gowoo_shiprice_license');

        return array(
            'woo_sl_action' => $action,
            'version' => WOOSHIPP_VERSION,
            'product_unique_id' => WOOSHIPP_PRODUCT_ID,
            'licence_key' => $settings['license_key'],
            'domain' => WOOSHIPP_INSTANCE,
            'wp-version' => $wp_version
        );
    }



    public function plugins_api_call($def, $action, $args) {
        
        if (!is_object($args) || !isset($args->slug) || $args->slug != $this->slug)
            return false;

        //$args->package_type = $this->package_type;

        $request_string = $this->prepare_request($action, $args);
        
        if($request_string === FALSE)
            return new WP_Error('plugins_api_failed', __('An error occour when try to identify the pluguin.' , 'apto') . '&lt;/p> &lt;p>&lt;a href=&quot;?&quot; onclick=&quot;document.location.reload(); return false;&quot;>'. __( 'Try again', 'apto' ) .'&lt;/a>');;

        $request_uri = WOOSHIPP_API_URL . '?' . http_build_query( $request_string , '', '&');
        $data = wp_remote_get( $request_uri );

        if(is_wp_error( $data ) || $data['response']['code'] != 200)
            return new WP_Error('plugins_api_failed', __('An Unexpected HTTP Error occurred during the API request.' , 'apto') . '&lt;/p> &lt;p>&lt;a href=&quot;?&quot; onclick=&quot;document.location.reload(); return false;&quot;>'. __( 'Try again', 'apto' ) .'&lt;/a>', $data->get_error_message());

        $response_block = json_decode($data['body']);
        //retrieve the last message within the $response_block
        $response_block = $response_block[count($response_block) - 1];
        $response = $response_block->message;

        if (is_object($response) && !empty($response)) { // Feed the update data into WP updater
            //include slug and plugin data
            $response->slug = $this->slug;
            $response->plugin = $this->plugin;
            $response->sections = (array)$response->sections;
            $response->banners = (array)$response->banners;

            return $response;
        }
    }

}

?>