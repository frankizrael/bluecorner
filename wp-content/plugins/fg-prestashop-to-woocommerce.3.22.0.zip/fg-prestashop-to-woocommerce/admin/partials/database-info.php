		<div id="fgp2wc_database_info">
			<h3><?php _e('WordPress database', 'fg-prestashop-to-woocommerce') ?></h3>
			<div id="fgp2wc_database_info_content">
				<?php print $data['database_info']; ?>
			</div>
		</div>
