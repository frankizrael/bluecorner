				<tr>
					<th scope="row">&nbsp;</th>
					<td><?php submit_button( __('Save settings', 'fg-prestashop-to-woocommerce'), 'secondary', 'save' ); ?>
					<?php submit_button( __('Start / Resume the import', 'fg-prestashop-to-woocommerce'), 'primary', 'import' ); ?>
					<span id="action_message" class="action_message"></span>
					<?php submit_button( __('Stop import', 'fg-prestashop-to-woocommerce'), 'secondary', 'stop-import' ); ?>
					</td>
				</tr>
