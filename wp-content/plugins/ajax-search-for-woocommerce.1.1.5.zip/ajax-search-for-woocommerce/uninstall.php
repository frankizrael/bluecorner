<?php
/**
 * Uninstall the plugin
 */
// Exit if accessed directly
if ( !defined( 'WP_UNINSTALL_PLUGIN' ) )
	exit;

//@todo deregister schedule